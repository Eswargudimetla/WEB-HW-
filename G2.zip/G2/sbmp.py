#!/usr/bin/env python3
import argparse, csv, json, re, time, os, glob, urllib.parse as up
from typing import List, Optional, Tuple
import requests
from bs4 import BeautifulSoup

# ----------------- utilities -----------------
def txt(el): 
    return el.get_text(" ", strip=True) if el else None

def parse_float_in_text(s: Optional[str]) -> Optional[float]:
    if not s: return None
    m = re.search(r"(\d+(?:\.\d+)?)", s)
    return float(m.group(1)) if m else None

def dedupe(rows, keys=("review","date")):
    seen, out = set(), []
    for r in rows:
        key = tuple((r.get(k) or "").strip() for k in keys)
        if key in seen: 
            continue
        seen.add(key)
        out.append(r)
    return out

# ----------------- page parsing -----------------
def extract_business(soup: BeautifulSoup) -> dict:
    # Name
    name = txt(soup.select_one("h1.y-css-1iiiexg, h1"))

    # Category: student's preferred selector first, then fallbacks
    category = None
    hit = soup.select("div[data-testid='biz-meta-info'] a[href*='cflt=']")
    if hit:
        category = ", ".join(dict.fromkeys([txt(h) for h in hit if txt(h)])) or None
    if not category:
        for sel in ["a[href*='/search?cflt=']","a[class*='category']","a[data-analytics*='category']"]:
            hits = soup.select(sel)
            if hits:
                category = ", ".join(dict.fromkeys([txt(h) for h in hits if txt(h)]))
                break
    if not category:
        # Try JSON-LD
        for sc in soup.select('script[type="application/ld+json"]'):
            try:
                data = json.loads(sc.string or sc.get_text() or "{}")
            except Exception:
                continue
            items = data if isinstance(data, list) else [data]
            cats = []
            for obj in items:
                at = obj.get("@type"); at = " ".join(at) if isinstance(at, list) else at
                if at and any(k in at for k in ["LocalBusiness","Restaurant","Hotel","Organization","TouristAttraction","Product"]):
                    for k in ("servesCuisine","category"):
                        v = obj.get(k)
                        if isinstance(v, list): cats += [str(x) for x in v if x]
                        elif v: cats.append(str(v))
            if cats:
                category = ", ".join(dict.fromkeys(cats))
                break

    # Overall rating: prefer aria-label so we keep exact float
    star = soup.select_one('[role="img"][aria-label*="star"], [aria-label*="of 5 bubbles"]')
    overall = parse_float_in_text(star["aria-label"]) if (star and star.has_attr("aria-label")) else None

    return {
        "business_name": name or "N/A",
        "business_category": category or "N/A",
        "overall_rating": overall if overall is not None else "N/A",
    }

def parse_reviews_from_html(html: str) -> Tuple[dict, List[dict]]:
    soup = BeautifulSoup(html, "lxml")
    biz = extract_business(soup)
    rows = []

    # Anchor on real profile links; fallback to generic review blocks
    candidates = soup.select('.user-passport-info a[href*="/user_details"]')
    blocks = []
    if candidates:
        for a in candidates:
            block = a.find_parent("li") or a.find_parent("article") or a.find_parent("div")
            if block: blocks.append((block, txt(a)))
    else:
        fb = soup.select('section[aria-label="Recommended Reviews"] article, div[class*="review-container"], li[class*="review"], article[class*="review"]')
        blocks = [(b, None) for b in fb]

    for block, forced_name in blocks:
        reviewer_name = forced_name or txt(block.select_one('a[href*="/user_details"]'))
        reviewer_location = txt(block.select_one('[data-testid="UserPassportInfoTextContainer"] span, div[data-testid="UserPassportInfoTextContainer"]')) or "N/A"

        date_el = block.select_one('[data-test-target*="review-date"], .y-css-scqtta span.y-css-1vi7y4e, time, span[class*="ratingDate"]')
        date = txt(date_el)
        if date:
            m = re.search(r"(\b\w+\s+\d{1,2},\s*\d{4}\b|\b\d{1,2}\s\w+\s\d{4}\b|\b\d{4}-\d{2}-\d{2}\b)", date)
            if m: date = m.group(1)

        star_el = block.select_one('[role="img"][aria-label*="star"], [aria-label*="star"], span[class*="ui_bubble_rating"]')
        star_rating = None
        if star_el and star_el.has_attr("aria-label"):
            star_rating = parse_float_in_text(star_el["aria-label"])
        else:
            cls = " ".join(star_el.get("class", [])) if star_el else ""
            m = re.search(r"bubble_(\d+)", cls)  # bubble_45 -> 4.5
            if m: star_rating = int(m.group(1)) / 10.0

        text_el = block.select_one('p.comment__09f24__D0cxf span.raw__09f24__T4Ezm, q span, p, span[class*="raw__"]')
        review_text = txt(text_el)

        # Skip junk/short rows
        if review_text and len(review_text) >= 20 and not any(k in review_text.lower() for k in ["things to do","best of"]):
            rows.append({
                "business_name": biz["business_name"],
                "business_category": biz["business_category"],
                "date": date or "N/A",
                "reviewer_name": reviewer_name or "N/A",
                "reviewer_location": reviewer_location,
                "review": review_text,
                "star_rating": star_rating if star_rating is not None else "N/A",
                "overall_rating": biz["overall_rating"],
            })

    return biz, dedupe(rows)

# ----------------- pagination helpers -----------------
def absolutize(base_url: str, href: str) -> str:
    if href.startswith("http"): 
        return href
    return up.urljoin(base_url, href)

def find_next_url(html: str, current_url: str) -> Optional[str]:
    soup = BeautifulSoup(html, "lxml")
    # Common patterns
    cand = (
        soup.select_one('a[rel="next"]')
        or soup.select_one('a.next-link')
        or soup.select_one('a.next')
        or soup.find("a", string=re.compile(r"\bNext\b", re.I))
    )
    if cand and cand.get("href"):
        return absolutize(current_url, cand["href"])

    # Fallback: Yelp often uses ?start=NN
    parsed = up.urlparse(current_url)
    q = dict(up.parse_qsl(parsed.query))
    if "start" in q:
        try:
            step = 10  # Yelp pages are typically 10 or 20 reviews per page
            nxt = int(q["start"]) + step
            q["start"] = str(nxt)
            new_q = up.urlencode(q)
            return up.urlunparse((parsed.scheme, parsed.netloc, parsed.path, "", new_q, ""))
        except Exception:
            pass
    else:
        # If no start param, add one for page 2
        # This is heuristic; adjust step if your listing shows 20 per page
        new_q = up.urlencode({**q, "start": "10"})
        return up.urlunparse((parsed.scheme, parsed.netloc, parsed.path, "", new_q, ""))

    return None

# ----------------- crawling (online) -----------------
def fetch_url(url: str, session: requests.Session, tries=3, backoff=1.5) -> Optional[str]:
    for i in range(tries):
        try:
            r = session.get(url, timeout=20)
            if r.status_code == 200:
                return r.text
            # stop on 403/404
            if r.status_code in (403, 404):
                return None
        except requests.RequestException:
            pass
        time.sleep(backoff * (i+1))
    return None

def crawl_online(start_url: str, pages: int) -> List[dict]:
    session = requests.Session()
    session.headers.update({
        "User-Agent": "SLUview-scraper/1.0 (+contact: student@slu.edu)",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
    })
    all_rows = []
    url = start_url
    for i in range(pages):
        html = fetch_url(url, session)
        if not html:
            print(f"[warn] failed to fetch page {i+1} at {url}")
            break
        _, rows = parse_reviews_from_html(html)
        if not rows:
            print(f"[info] no reviews parsed on page {i+1}")
        all_rows.extend(rows)
        next_url = find_next_url(html, url)
        if not next_url:
            print("[info] no next page link found; stopping.")
            break
        url = next_url
    return dedupe(all_rows)

# ----------------- crawling (offline saved files) -----------------
def crawl_offline(glob_pattern: str, pages: int) -> List[dict]:
    files = sorted(glob.glob(glob_pattern))[:pages]
    if not files:
        print(f"[warn] no files matched {glob_pattern}")
        return []
    all_rows = []
    for i, path in enumerate(files, 1):
        with open(path, "rb") as f:
            html = f.read().decode("utf-8", errors="ignore")
        _, rows = parse_reviews_from_html(html)
        if not rows:
            print(f"[info] no reviews parsed in {path}")
        all_rows.extend(rows)
    return dedupe(all_rows)

# ----------------- IO -----------------
def save_outputs(rows: List[dict], json_path="data.json", csv_path="reviews.csv"):
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2)
    if rows:
        cols = ["business_name","business_category","date","reviewer_name",
                "reviewer_location","review","star_rating","overall_rating"]
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=cols)
            w.writeheader()
            for r in rows: w.writerow({k: r.get(k, "N/A") for k in cols})

# ----------------- main -----------------
def main():
    ap = argparse.ArgumentParser(description="Multi-page review scraper (Yelp/TripAdvisor-like).")
    ap.add_argument("--url", help="Starting URL (online mode).")
    ap.add_argument("--local-glob", help="Offline mode: glob of saved HTML files (e.g., listing*.html).")
    ap.add_argument("--pages", type=int, default=3, help="How many pages to scrape (default 3).")
    ap.add_argument("--json-out", default="data.json", help="JSON output filename (default data.json).")
    ap.add_argument("--csv-out", default="reviews.csv", help="CSV output filename (default reviews.csv).")
    args = ap.parse_args()

    if not args.url and not args.local_glob:
        ap.error("Provide either --url (online) or --local-glob (offline).")

    if args.url:
        rows = crawl_online(args.url, args.pages)
    else:
        rows = crawl_offline(args.local_glob, args.pages)

    print(f"[done] parsed {len(rows)} reviews")
    save_outputs(rows, args.json_out, args.csv_out)

    # Assignment note: want at least 15 reviews for SLUview
    if len(rows) < 15:
        print("[note] fewer than 15 reviews gathered — either increase --pages or ensure pages have reviews loaded.")

if __name__ == "__main__":
    main()
