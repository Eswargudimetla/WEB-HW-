#!/usr/bin/env python3
import argparse, csv, json, re, time, urllib.parse as up
from typing import List, Optional, Tuple
import requests
from bs4 import BeautifulSoup

# ---------- helpers ----------
def txt(el): return el.get_text(" ", strip=True) if el else None
def fnum(s): 
    if not s: return None
    m = re.search(r"(\d+(?:\.\d+)?)", s)
    return float(m.group(1)) if m else None

def dedupe(rows, keys=("business_name","review","date")):
    seen, out = set(), []
    for r in rows:
        key = tuple((r.get(k) or "").strip() for k in keys)
        if key not in seen:
            seen.add(key); out.append(r)
    return out

# ---------- page parsing ----------
def extract_business(soup: BeautifulSoup) -> dict:
    name = txt(soup.select_one("h1.y-css-1iiiexg, h1"))
    # Preferred category selector (your choice) + fallbacks
    category = None
    hit = soup.select("div[data-testid='biz-meta-info'] a[href*='cflt=']")
    if hit:
        category = ", ".join(dict.fromkeys([txt(h) for h in hit if txt(h)])) or None
    if not category:
        for sel in ["a[href*='/search?cflt=']","a[class*='category']","a[data-analytics*='category']"]:
            hs = soup.select(sel)
            if hs:
                category = ", ".join(dict.fromkeys([txt(h) for h in hs if txt(h)]))
                break
    if not category:
        # JSON-LD fallback
        for sc in soup.select('script[type="application/ld+json"]'):
            try: data = json.loads(sc.string or sc.get_text() or "{}")
            except Exception: continue
            items = data if isinstance(data, list) else [data]
            cats = []
            for obj in items:
                at = obj.get("@type"); at = " ".join(at) if isinstance(at, list) else at
                if at and any(k in at for k in ["LocalBusiness","Restaurant","Hotel","Organization","TouristAttraction","Product"]):
                    for k in ("servesCuisine","category"):
                        v = obj.get(k)
                        if isinstance(v, list): cats += [str(x) for x in v if x]
                        elif v: cats.append(str(v))
            if cats:
                category = ", ".join(dict.fromkeys(cats))
                break
    star = soup.select_one('[role="img"][aria-label*="star"], [aria-label*="of 5 bubbles"]')
    overall = fnum(star["aria-label"]) if (star and star.has_attr("aria-label")) else None
    return {
        "business_name": name or "N/A",
        "business_category": category or "N/A",
        "overall_rating": overall if overall is not None else "N/A",
    }

def parse_reviews_from_html(html: str) -> List[dict]:
    soup = BeautifulSoup(html, "lxml")
    biz = extract_business(soup)
    rows = []

    candidates = soup.select('.user-passport-info a[href*="/user_details"]')
    blocks = []
    if candidates:
        for a in candidates:
            block = a.find_parent("li") or a.find_parent("article") or a.find_parent("div")
            if block: blocks.append((block, txt(a)))
    else:
        fb = soup.select('section[aria-label="Recommended Reviews"] article, div[class*="review-container"], li[class*="review"], article[class*="review"]')
        blocks = [(b, None) for b in fb]

    for block, forced_name in blocks:
        reviewer_name = forced_name or txt(block.select_one('a[href*="/user_details"]'))
        reviewer_location = txt(block.select_one('[data-testid="UserPassportInfoTextContainer"] span, div[data-testid="UserPassportInfoTextContainer"]')) or "N/A"

        date_el = block.select_one('[data-test-target*="review-date"], .y-css-scqtta span.y-css-1vi7y4e, time, span[class*="ratingDate"]')
        date = txt(date_el)
        if date:
            m = re.search(r"(\b\w+\s+\d{1,2},\s*\d{4}\b|\b\d{1,2}\s\w+\s\d{4}\b|\b\d{4}-\d{2}-\d{2}\b)", date)
            if m: date = m.group(1)

        star_el = block.select_one('[role="img"][aria-label*="star"], [aria-label*="star"], span[class*="ui_bubble_rating"]')
        star_rating = None
        if star_el and star_el.has_attr("aria-label"):
            star_rating = fnum(star_el["aria-label"])
        else:
            cls = " ".join(star_el.get("class", [])) if star_el else ""
            m = re.search(r"bubble_(\d+)", cls)  # bubble_45 -> 4.5
            if m: star_rating = int(m.group(1)) / 10.0

        text_el = block.select_one('p.comment__09f24__D0cxf span.raw__09f24__T4Ezm, q span, p, span[class*="raw__"]')
        review_text = txt(text_el)

        if review_text and len(review_text) >= 20 and not any(k in review_text.lower() for k in ["things to do","best of"]):
            rows.append({
                "business_name": biz["business_name"],
                "business_category": biz["business_category"],
                "date": date or "N/A",
                "reviewer_name": reviewer_name or "N/A",
                "reviewer_location": reviewer_location,
                "review": review_text,
                "star_rating": star_rating if star_rating is not None else "N/A",
                "overall_rating": biz["overall_rating"],
            })
    return dedupe(rows)

# ---------- pagination (simple/robust) ----------
def absolutize(base_url: str, href: str) -> str:
    return href if href.startswith("http") else up.urljoin(base_url, href)

def find_next_url(html: str, current_url: str) -> Optional[str]:
    soup = BeautifulSoup(html, "lxml")
    cand = (
        soup.select_one('a[rel="next"]') or
        soup.select_one('a.next-link') or
        soup.select_one('a.next') or
        soup.find("a", string=re.compile(r"\bNext\b", re.I))
    )
    if cand and cand.get("href"):
        return absolutize(current_url, cand["href"])
    # Fallback: Yelp often uses ?start=NN
    p = up.urlparse(current_url)
    q = dict(up.parse_qsl(p.query))
    if "start" in q:
        try:
            step = 10
            q["start"] = str(int(q["start"]) + step)
            return up.urlunparse((p.scheme, p.netloc, p.path, "", up.urlencode(q), ""))
        except Exception:
            return None
    else:
        # go to page 2 heuristically
        return up.urlunparse((p.scheme, p.netloc, p.path, "", up.urlencode({**q,"start":"10"}), ""))

def fetch_url(url: str, session: requests.Session, tries=3, backoff=1.6) -> Optional[str]:
    for i in range(tries):
        try:
            r = session.get(url, timeout=20)
            if r.status_code == 200:
                return r.text
            if r.status_code in (403,404):
                return None
        except requests.RequestException:
            pass
        time.sleep(backoff*(i+1))
    return None

def crawl_business(start_url: str, pages: int, session: requests.Session) -> List[dict]:
    url = start_url
    all_rows = []
    for i in range(pages):
        html = fetch_url(url, session)
        if not html:
            print(f"[warn] failed to fetch p{i+1} for {start_url}")
            break
        rows = parse_reviews_from_html(html)
        all_rows.extend(rows)
        next_url = find_next_url(html, url)
        if not next_url:
            break
        url = next_url
    return all_rows

# ---------- main ----------
def main():
    ap = argparse.ArgumentParser(description="Multi-URL Yelp-like scraper.")
    ap.add_argument("--urls", nargs="+", required=True, help="One or more business URLs (space-separated).")
    ap.add_argument("--pages-per", type=int, default=3, help="Pages per business to scrape (default 3).")
    ap.add_argument("--json-out", default="data.json")
    ap.add_argument("--csv-out", default="reviews.csv")
    args = ap.parse_args()

    session = requests.Session()
    session.headers.update({
        "User-Agent": "SLUview-scraper/1.0 (+contact: student@slu.edu)",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
    })

    all_rows = []
    for u in args.urls:
        print(f"[info] scraping: {u}")
        all_rows.extend(crawl_business(u, args.pages_per, session))

    all_rows = dedupe(all_rows)
    # Save JSON (SLUview)
    with open(args.json_out, "w", encoding="utf-8") as f:
        json.dump(all_rows, f, ensure_ascii=False, indent=2)

    # Save CSV
    if all_rows:
        cols = ["business_name","business_category","date","reviewer_name",
                "reviewer_location","review","star_rating","overall_rating"]
        with open(args.csv_out, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=cols); w.writeheader()
            for r in all_rows: w.writerow({k: r.get(k,"N/A") for k in cols})

    print(f"[done] saved {len(all_rows)} reviews → {args.json_out} & {args.csv_out}")
    if len(all_rows) < 15:
        print("[note] fewer than 15 reviews; increase --pages-per or add more URLs.")

if __name__ == "__main__":
    main()
